# fintech-homeowork
Fintech domain (canadian)
